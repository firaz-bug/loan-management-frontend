import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
// @mui
import { Link, Stack, IconButton, InputAdornment, TextField, Checkbox } from '@mui/material';
import { LoadingButton } from '@mui/lab';
// components
import Iconify from '../../components/iconify';
import { updateEmployee, getEmployeeById } from '../../api/UserApi';
// ----------------------------------------------------------------------

export default function EditUserForm() {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [employeeName, setName] = useState("");
  const [gender, setGender] = useState("");
  const [date_of_birth, setDob] = useState("");
  const [salary, setSalary] = useState("");
  const [email, setEmail] = useState("");
  const [date_of_joining, setDoj] = useState("");
  const [mobile, setMobile] = useState("");
  const [department, setDepartment] = useState("");
  const [designation, setDesignation] = useState("");
  const [role, setRole] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const params=useParams();

  useEffect(() => {
      return async ()=>{
      console.log(params.id);

       const result = await getEmployeeById(params.id);
       console.log("return from get");
       setName(result.employee_name);
       setGender(result.gender);
       setDepartment(result.department);
       setDesignation(result.designation);
       setSalary(result.salary);
       setEmail(result.email);
       setDoj(result.date_of_joining);
       setMobile(result.mobile);
       setDob(result.date_of_birth);
       setRole(result.role);
       setUsername(result.username);
       setPassword(result.password);
      }
  }, []);

  const onNameChange = (e) => {
      setName(e.target.value);
  };
  const onGenderChange = (e) => {
      setGender(e.target.value);
  };
  const onDepartmentChange = (e) => {
      setDepartment(e.target.value);
  };
  const onDesignationChange = (e) => {
      setDesignation(e.target.value);
  };
  const onDobChange = (e) => {
      setDob(e.target.value);
  };
  const onSalaryChange = (e) => {
      setSalary(e.target.value);
  };
  const onEmailChange = (e) => {
      setEmail(e.target.value);
  };
  const onDojChange = (e) => {
      setDoj(e.target.value);
  };
  function onMobileChange(e) {
      setMobile(e.target.value);
  };
  function onRoleChange(e) {
      setRole(e.target.value);
  }

  function onUsernameChange(e){
      setUsername(e.target.value);
  }
  function onPasswordChange(e){
    setPassword(e.target.value);
  }

  const handleUpdateEmployee = async (e) => {
      e.preventDefault();
      const employee = {
          employeeName,
          gender,
          date_of_birth,
          salary,
          email,
          date_of_joining,
          mobile,
          department, 
          designation,
          role,
          username,
          password  
      };
      await updateEmployee(params.id,employee)

      navigate('/dashboard/user', { replace: true });
  };

  return (
    <>
      <Stack spacing={3}>
        <TextField name="name" label="Name" type='text' value={employeeName} onChange={onNameChange}/>
        <TextField name="mobile" label="Mobile" type='text' onChange={onMobileChange}/>
        <TextField name="email" label="Email address" type='email' on onChange={onEmailChange}/>
        <TextField name="username" label="Username" type='text' onChange={onUsernameChange}/>
        <TextField name="role" label="Role" type='text' onChange={onRoleChange}/>
        <TextField name="gender" label="Gender" type='text' on onChange={onGenderChange}/>
        <TextField name="salary" label="Salary" type='number' onChange={onSalaryChange}/>
        <TextField name="Date of Birth" label="Date of Birth" type='date' onChange={onDobChange}/>
        <TextField name="Date of Joining" label="Date of Joining" type='date' on onChange={onDojChange}/>
        <TextField name="Department" label="Department" type='text' onChange={onDepartmentChange}/>
        <TextField name="Designation" label="Designation" type='text' onChange={onDesignationChange}/>
        <TextField
          name="password"
          label="Password"
          type={showPassword ? 'text' : 'password'}
          onChange={onPasswordChange}
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton onClick={() => setShowPassword(!showPassword)} edge="end">
                  <Iconify icon={showPassword ? 'eva:eye-fill' : 'eva:eye-off-fill'} />
                </IconButton>
              </InputAdornment>
            ),
          }}
        />
      </Stack>
      <br/>
      <LoadingButton fullWidth size="large" type="submit" variant="contained" onClick={handleUpdateEmployee}>
        Edit Employee
      </LoadingButton>
    </>
  );
}
