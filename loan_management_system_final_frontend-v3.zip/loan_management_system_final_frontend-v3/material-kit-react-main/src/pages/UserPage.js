import { Helmet } from 'react-helmet-async';
import { filter } from 'lodash';
import { sentenceCase } from 'change-case';
import { useState , useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
// @mui
import {
  Card,
  Table,
  Stack,
  Paper,
  Avatar,
  Button,
  Popover,
  Checkbox,
  TableHead,
  TableRow,
  MenuItem,
  TableBody,
  TableCell,
  Container,
  Typography,
  IconButton,
  TableContainer,
  TablePagination,
} from '@mui/material';
// components
import Label from '../components/label';
import Iconify from '../components/iconify';
import Scrollbar from '../components/scrollbar';
// sections
import { UserListHead, UserListToolbar } from '../sections/@dashboard/user';
// mock
import USERLIST from '../_mock/user';
import { addEmployee, getAll, deleteEmployee, updateEmployee, getEmployeeById } from '../api/UserApi';



export default function UserPage() {
  const [employees, setEmployees] = useState([]);
  const [open, setOpen] = useState(null);
  const navigate = useNavigate();
  const [Id, setId] = useState(0);
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await getAll();
        setEmployees(response);
        console.log(response);
        console.log("use effect triggered ");
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  const HandleDelete = async (employeeId) => {
    console.log(employeeId);

    try {
      await deleteEmployee(employeeId);
      setEmployees((prevEmployees) =>
        prevEmployees.filter((employee) => employee.employeeId !== employeeId)
      );
    } catch (error) {
      console.error('Error deleting employee:', error);
    }
  };

  const HandleAdduser = () => {
    alert("you have clicked edit");
    navigate('/dashboard/adduser');
  };

  return (
    <>
      <Helmet>
        <title> Loan Management </title>
      </Helmet>
      <Container>
      <Stack direction="row" alignItems="center" justifyContent="space-between" mb={5}>
            <Typography variant="h4" gutterBottom>
              Employee
            </Typography>
            <Button onClick={HandleAdduser} variant="contained" startIcon={<Iconify icon="eva:plus-fill" />}>
              New Employee
            </Button>
          </Stack>
   
      <TableContainer component={Paper}>
        
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell align="right">Employee Id</TableCell>
            <TableCell>Name and Contact </TableCell>
            <TableCell align="right">Username</TableCell>
            <TableCell align="right">Date of Birth</TableCell>
            <TableCell align="right">Role</TableCell>
            <TableCell align="right">Gender</TableCell>
            <TableCell align="right">Date of joining</TableCell>
            <TableCell align="right">Department</TableCell>
            <TableCell align="right">Designation</TableCell>
            <TableCell align="right">Salary</TableCell>
            <TableCell align="right">Action</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {employees.map((employee) => (
            <TableRow
              key={employee.employeeId}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell align="right">{employee.employeeId}</TableCell>
              <TableCell component="th" scope="row">
                {employee.employeeName}
                <br/>
                {employee.email}
                <br/>
                {employee.mobile}
              </TableCell>
              <TableCell align="right">{employee.username}</TableCell>
              <TableCell align="right">{employee.date_of_birth}</TableCell>
              <TableCell align="right">{employee.role}</TableCell>
              <TableCell align="right">{employee.gender}</TableCell>
              <TableCell align="right">{employee.date_of_joining}</TableCell>
              <TableCell align="right">{employee.department}</TableCell>
              <TableCell align="right">{employee.designation}</TableCell>
              <TableCell align="right">{employee.salary}</TableCell>
              <TableCell>                          
                  <Link style={{ textDecoration: 'none' }} to={`/dashboard/updateuser/${employee.employeeId}`} id = {employee.employeeId}>
                    <MenuItem>
                      <Iconify icon={'eva:edit-fill'} sx={{ mr: 2 }} />
                      Edit
                    </MenuItem>
                  </Link>
                  <MenuItem onClick={() => HandleDelete(employee.employeeId)} sx={{ color: 'error.main' }}>
                    <Iconify icon={'eva:trash-2-outline'} sx={{ mr: 2 }} />
                    Delete
                  </MenuItem>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    </Container>
    </>
  );
}
