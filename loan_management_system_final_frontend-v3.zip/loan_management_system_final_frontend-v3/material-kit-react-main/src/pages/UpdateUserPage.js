import { Helmet } from 'react-helmet-async';
// @mui
import { styled } from '@mui/material/styles';
import { Link, Container, Typography, Divider, Stack, Button } from '@mui/material';
// hooks
import useResponsive from '../hooks/useResponsive';
// components
import Logo from '../components/logo';
// sections
import { AddUserForm } from '../sections/forms';
import EditUserForm from 'src/sections/forms/EditUserForm';


export default function UpdateUserPage() {
  const mdUp = useResponsive('up', 'md');

  return (
    <>
      <Helmet>
        <title> Edit User Details | Loan Management </title>
      </Helmet>
      <br/>
      <br/>
        <Container maxWidth="sm">
            <Typography variant="h4" gutterBottom>
              Edit Employee Details | Loan Management
            </Typography>
            <br/>
            <EditUserForm />
        </Container>
    </>
  );
}