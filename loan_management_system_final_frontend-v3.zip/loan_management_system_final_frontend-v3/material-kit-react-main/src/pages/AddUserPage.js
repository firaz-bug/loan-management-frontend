import { Helmet } from 'react-helmet-async';
// @mui
import { styled } from '@mui/material/styles';
import { Link, Container, Typography, Divider, Stack, Button } from '@mui/material';
// hooks
import useResponsive from '../hooks/useResponsive';
// components
import Logo from '../components/logo';
// sections
import { AddUserForm } from '../sections/forms';


export default function AddUserPage() {
  const mdUp = useResponsive('up', 'md');

  return (
    <>
      <Helmet>
        <title> Add Employee | Loan Management </title>
      </Helmet>
      <br/>
      <br/>
        <Container maxWidth="sm">
            <Typography variant="h4" gutterBottom>
              Add Employee | Loan Management
            </Typography>
            <br/>
            <AddUserForm />
        </Container>
    </>
  );
}
