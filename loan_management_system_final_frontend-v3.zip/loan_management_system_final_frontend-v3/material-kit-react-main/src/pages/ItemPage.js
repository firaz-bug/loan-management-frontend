import { Helmet } from 'react-helmet-async';
import { filter } from 'lodash';
import { sentenceCase } from 'change-case';
import { useState , useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
// @mui
import {
  Card,
  Table,
  Stack,
  Paper,
  Avatar,
  Button,
  Popover,
  Checkbox,
  TableHead,
  TableRow,
  MenuItem,
  TableBody,
  TableCell,
  Container,
  Typography,
  IconButton,
  TableContainer,
  TablePagination,
} from '@mui/material';
// components
import Label from '../components/label';
import Iconify from '../components/iconify';
import Scrollbar from '../components/scrollbar';
// sections
import { UserListHead, UserListToolbar } from '../sections/@dashboard/user';
// mock
import USERLIST from '../_mock/user';
import { addEmployee, getAll, deleteEmployee, updateEmployee, getEmployeeById } from '../api/UserApi';
import { getAllItems } from 'src/api/ItemApi';



export default function ItemPage() {
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(null);
  const navigate = useNavigate();
  const [Id, setId] = useState(0);
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await getAllItems();
        setItems(response);
        console.log(response);
        console.log("use effect triggered ");
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  const HandleDelete = async (itemId) => {
    console.log(itemId);

    try {
      await deleteItem(itemId);
      setItems((prevItems) =>
        prevItems.filter((item) => item.itemId !== itemId)
      );
    } catch (error) {
      console.error('Error deleting employee:', error);
    }
  };

  const HandleAdditem = () => {
    alert("you have clicked edit");
    navigate('/dashboard/additem');
  };

  return (
    <>
      <Helmet>
        <title> Loan Management </title>
      </Helmet>
      <Container>
      <Stack direction="row" alignItems="center" justifyContent="space-between" mb={5}>
            <Typography variant="h4" gutterBottom>
              Item
            </Typography>
            <Button onClick={HandleAdditem} variant="contained" startIcon={<Iconify icon="eva:plus-fill" />}>
              New Item
            </Button>
          </Stack>
   
      <TableContainer component={Paper}>
        
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell align="right">Employee Id</TableCell>
            <TableCell>Name and Contact </TableCell>
            <TableCell align="right">Username</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {items.map((item) => (
            <TableRow
              key={item.itemId}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell align="right">{employee.employeeId}</TableCell>
              <TableCell component="th" scope="row">
                {item.itemId}
              </TableCell>
              <TableCell align="right">{item.item_status}</TableCell>
              <TableCell align="right">{item.item_category}</TableCell>
              <TableCell>                          
                  <Link style={{ textDecoration: 'none' }}>
                    <MenuItem>
                      <Iconify icon={'eva:edit-fill'} sx={{ mr: 2 }} />
                      Edit
                    </MenuItem>
                  </Link>
li                  <MenuItem  sx={{ color: 'error.main' }}>
                    <Iconify icon={'eva:trash-2-outline'} sx={{ mr: 2 }} />
                    Delete
                  </MenuItem>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    </Container>
    </>
  );
}
