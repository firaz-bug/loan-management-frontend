import axios from "axios";

const addNewLoanCard = async (loan) => {
  console.log(loan);
  const response = await axios.post(
    "http://localhost:8080/api/loancard",
    loan
  );
  console.log(response);
};

const getAllLoanCard = async () => {
  const response = await axios.get("http://localhost:8080/api/loancard");
  console.log("This is from get All", response.data);
  return response.data;
};

const deleteLoanCard = async (id) => {
  console.log(id);
  const response = await axios.delete(`http://localhost:8080/api/loancard/${id}`);
}

const updateLoanCard = async (id, loan) => {
  console.log(id);
  console.log(loan);
  const response = await axios.put(`http://localhost:8080/api/loancard/${id}`, employee);
  return response.data;
}

const findLoanCardById = async (id) => {
  console.log(id);
  const response = await axios.get(`http://localhost:8080/api/loancard/${id}`);
  console.log("hello");
  console.log(response.data)
  return response.data;
}

export { addNewLoanCard, getAllLoanCard, deleteLoanCard, updateLoanCard, findLoanCardById };
