import axios from "axios";

const addItem = async (item) => {
  console.log(item);
  const response = await axios.post(
    "http://localhost:8080/api/items",
    item
  );
};

const getAllItems = async () => {
  const response = await axios.get("http://localhost:8080/api/items");
  console.log("This is from get All", response.data);
  return response.data;
};

const deleteItem = async (id) => {
  console.log(id);
  const response = await axios.delete(`http://localhost:8080/api/items/${id}`);
}

const updateItem = async (id, item) => {
  console.log(id);
  console.log(item);
  const response = await axios.put(`http://localhost:8080/api/items/${id}`, employee);
  return response.data;
}

const findItemById = async (id) => {
  console.log(id);
  const response = await axios.get(`http://localhost:8080/api/items/${id}`);
  console.log("hello");
  console.log(response.data)
  return response.data;
}

export { addItem, getAllItems, deleteItem, updateItem, findItemById };
