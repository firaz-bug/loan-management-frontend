import axios from "axios";

const addEmployee = async (employee) => {
  console.log(employee);
  const response = await axios.post(
    "http://localhost:8080/api/employees",
    employee
  );
  console.log(response);
};

const getAll = async () => {
  const response = await axios.get("http://localhost:8080/api/employees");
  console.log("This is from get All", response.data);
  return response.data;
};

const deleteEmployee = async (id) => {
  console.log(id);
  const response = await axios.delete(`http://localhost:8080/api/employees/${id}`);
}

const updateEmployee = async (id, employee) => {
  console.log(id);
  console.log(employee);
  const response = await axios.put(`http://localhost:8080/api/employees/${id}`, employee);
  return response.data;
}

const getEmployeeById = async (id) => {
  console.log(id);
  const response = await axios.get(`http://localhost:8080/api/employees/${id}`);
  console.log("hello");
  console.log(response.data)
  return response.data;
}

export { addEmployee, getAll, deleteEmployee, updateEmployee, getEmployeeById };
