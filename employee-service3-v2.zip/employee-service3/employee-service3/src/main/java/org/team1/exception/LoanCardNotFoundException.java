package org.team1.exception;

public class LoanCardNotFoundException extends RuntimeException {
	public LoanCardNotFoundException() {
		super();
	}
	
	public LoanCardNotFoundException(String msg) {
		super(msg);
	}
}
