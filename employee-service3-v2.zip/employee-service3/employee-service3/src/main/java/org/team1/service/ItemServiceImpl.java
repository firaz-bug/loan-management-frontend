package org.team1.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.team1.entities.Employee;
import org.team1.entities.Item;
import org.team1.exception.EmployeeAppException;
import org.team1.exception.EmployeeNotFoundException;
import org.team1.exception.ItemNotFoundException;
import org.team1.repositories.ItemRepository;

@Service
public class ItemServiceImpl implements ItemService{
	@Autowired
	private ItemRepository itemRepo;

	@Override
	public Item addItem(Item item) {
		// TODO Auto-generated method stub
		return itemRepo.save(item);
	}

	@Override
	public List<Item> getAll_I() {
		// TODO Auto-generated method stub
		return itemRepo.findAll();
	}

	@Override
	public void deleteItem(int id) {
		// TODO Auto-generated method stub
		Optional<Item> optionalItem = itemRepo.findById(id);
		if(!optionalItem.isPresent()) {
			throw new ItemNotFoundException("Item with id "+ id +" not found.");
		}
		
		itemRepo.deleteById(id);
		
	}
	
	@Override
	public String updateItem(int id, Item item) {
		item.setItemId(id);
		itemRepo.save(item);
		
		return "Item with id "+id+" updated successfully";
	}

	@Override
	public Item findItemById(int id) {
		Item item=itemRepo.findById(id)
				.orElseThrow(()->new EmployeeAppException(HttpStatus.NOT_FOUND, "Item with Id "+id +" not found"));
		return item;
	}
	

}

