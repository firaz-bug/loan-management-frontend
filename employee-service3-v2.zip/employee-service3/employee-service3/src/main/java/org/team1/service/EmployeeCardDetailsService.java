package org.team1.service;

import java.util.List;

import org.team1.entities.EmployeeCardDetails;


public interface EmployeeCardDetailsService {

	EmployeeCardDetails addCardDetails(EmployeeCardDetails employeeCarddDetails);

	List<EmployeeCardDetails> getAll();
	void deleteEmployeeCardDetails(int id);
	EmployeeCardDetails findEmployeeCardDetailsById(int id);
}
