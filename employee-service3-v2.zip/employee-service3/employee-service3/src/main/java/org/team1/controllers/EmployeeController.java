package org.team1.controllers;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.team1.entities.Employee;
import org.team1.service.EmployeeService;

import jakarta.validation.Valid;

@RestController
@CrossOrigin
@RequestMapping("/api/employees")
public class EmployeeController {
	@Autowired
	private EmployeeService employeeService;

	@PostMapping
	public ResponseEntity<Employee> addEmployee(@Valid  @RequestBody Employee employee){
		
		Employee emp=employeeService.addEmployee(employee);
			
		return new ResponseEntity<Employee>(emp,HttpStatus.CREATED);		
	}
	
	@GetMapping
//	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	public List<Employee> getAllEmployees(){
		return employeeService.getAll();
	}
	
	@DeleteMapping("/{employee_id}")
	public void deleteEmployee(@PathVariable int employee_id){
		 employeeService.deleteEmployee(employee_id);
	}
	
	@PutMapping("/{employee_id}")
	public String updateEmployee(@PathVariable int employee_id,@RequestBody Employee employee) {
		
		return employeeService.updateEmployee(employee_id, employee);
	}
	
	@GetMapping("/{employee_id}")
	public Employee findEmployeeById(@PathVariable int employee_id) {
		
		return employeeService.findEmployeeById(employee_id);
	}

}
