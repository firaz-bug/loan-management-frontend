package org.team1.exception;

public class EmployeeCardDetailsNotFoundException extends RuntimeException {
	public EmployeeCardDetailsNotFoundException() {
		super();
	}
	
	public EmployeeCardDetailsNotFoundException(String msg) {
		super(msg);
	}
}
