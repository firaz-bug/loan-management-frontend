package org.team1.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import org.team1.entities.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
	Optional<Employee> findByEmployeeName(String username);
}
