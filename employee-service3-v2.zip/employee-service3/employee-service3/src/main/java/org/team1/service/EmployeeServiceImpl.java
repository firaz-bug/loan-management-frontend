package org.team1.service;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
/*import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;*/
import org.springframework.stereotype.Service;
import org.team1.entities.Employee;
import org.team1.entities.EmployeeDetails;
import org.team1.exception.EmployeeNotFoundException;
import org.team1.exception.UsernameNotFoundException;
import org.team1.exception.EmployeeAppException;
import org.team1.repositories.EmployeeRepository;

import jakarta.transaction.Transactional;

@Service
public class EmployeeServiceImpl implements EmployeeService, UserDetailsService {
	@Autowired
	private EmployeeRepository employeeRepository;
	
	 @Autowired
	 private PasswordEncoder encoder;
	
	@Override
	@Transactional
	public Employee addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeeRepository.save(employee);
	}

	@Override
	public List<Employee> getAll() {
		// TODO Auto-generated method stub
		return employeeRepository.findAll();
	}

	@Override
	public void deleteEmployee(int id) {
		// TODO Auto-generated method stub
		Optional<Employee> optionalEmployee = employeeRepository.findById(id);
		if(!optionalEmployee.isPresent()) {
			throw new EmployeeNotFoundException("Employee with id "+ id +" not found.");
		}
		
		employeeRepository.deleteById(id);
	}
	
	@Override
	public String updateEmployee(int id, Employee employee) {
		employee.setEmployeeId(id);
		employeeRepository.save(employee);
		
		return "Employee with id "+id+" updated successfully";
	}

	@Override
	public Employee findEmployeeById(int id) {
		Employee employee=employeeRepository.findById(id)
				.orElseThrow(()->new EmployeeAppException(HttpStatus.NOT_FOUND, "Employee with Id "+id +" not found"));
		return employee;
	}
	
	
	  
	    @Override
	    public EmployeeDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	  
	        Optional<Employee> userDetail = employeeRepository.findByEmployeeName(username);
	  
	        // Converting userDetail to UserDetails
	        return userDetail.map(EmployeeDetails::new)
	                .orElseThrow(() -> new UsernameNotFoundException("User not found " + username));
	    }
	  
	    public Employee addUser(Employee employee) {
	        employee.setPassword(encoder.encode(employee.getPassword()));
	        employeeRepository.save(employee);
	        return employee;
	    }

}
