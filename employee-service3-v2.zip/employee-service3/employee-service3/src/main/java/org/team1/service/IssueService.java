package org.team1.service;

import java.util.List;

import org.team1.entities.Issue;

public interface IssueService {
	Issue addIssue(Issue issue);
	List<Issue> getAll();
	Issue findIssueById(int id);
//	List<Issue> findIssuesByEmployeeId(int employee_id);

}
