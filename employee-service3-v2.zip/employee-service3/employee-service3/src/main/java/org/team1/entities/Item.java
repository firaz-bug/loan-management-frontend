package org.team1.entities;

import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="item_master")
public class Item {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="item_id")
	private int itemId;
	
	@Column(nullable = false)
	private String item_description;
	
	@Column(nullable= false)
	@Pattern(regexp = "(Pending|Approved|Rejected)",message = "Status should be either Pending or Approved or Rejected")
	private String issue_status;

	
	private String item_make;
	
	@Column(nullable= false)
	private String item_category;
	
	private int item_valuation;
	
}
