package org.team1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.team1.entities.Employee;
import org.team1.entities.Issue;
import org.team1.exception.EmployeeAppException;
import org.team1.repositories.IssueRepository;

@Service
public class IssueServiceImpl implements IssueService  {
	@Autowired
	private IssueRepository issueRepo;

	@Override
	public Issue addIssue(Issue issue) {
		// TODO Auto-generated method stub
		return issueRepo.save(issue);
	}

	@Override
	public List<Issue> getAll() {
		// TODO Auto-generated method stub
		return issueRepo.findAll();
	}

	@Override
	public Issue findIssueById(int id) {
		Issue issue=issueRepo.findById(id)
				.orElseThrow(()->new EmployeeAppException(HttpStatus.NOT_FOUND, "Employee with Id "+id +" not found"));
		return issue;
	}
	
//	@Override
//    public List<Issue> findIssuesByEmployeeId(int employee_id) {
//        return issueRepo.findByEmployeeEmployeeId(employee_id);
//    }
	
	

}
