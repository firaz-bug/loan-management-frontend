package org.team1.entities;

//import java.time.LocalDate;
import java.util.Date;
//import java.util.List;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
//import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.Email;
//import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="employee_master")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="employee_id")
	private int employeeId;
	
	/*private String password;*/
//	
//	@Column(nullable= false, columnDefinition = "TINYINT(1)")
//	private boolean is_admin;
	
	@Column(nullable = false, name="employee_name")
	@Size(max=50, message="Name must be less than or equal to 50 characters")
	private String employeeName;
	
	@Column(nullable= false)
	@Size(max=20, message = "Designation must be less than or equal to 20 characters")
	private String designation;
	
	@Column(nullable= false)
	@Size(max=20, message = "Department must be less than or equal to 20 characters")
	private String department;
	
	@Pattern(regexp = "(Male|Female|Other)",message = "Gender should be either Male or Female or Other")
	private String gender;
	
	@Column(nullable=false)
	@Past(message = "Date of birth must be in the past")
	@Temporal(TemporalType.DATE)
	private Date date_of_birth;
	
	@Column(nullable=false)
	@Temporal(TemporalType.DATE)
	private Date date_of_joining;
	
	@Min(0)
	private double salary;
	
	@Column(nullable = false,unique = true)
	@Email(message = "Invalid Email Id")
	private String email;

	@Pattern(regexp = "[9876][0-9]{9}",message = "Invalid mobile number")
	private String mobile;
	
	@Column(nullable = false, unique = true)
	private String username;
	
	@Column(nullable = false)
	private String password;
	
	@Column(nullable = false, columnDefinition = "VARCHAR(255) DEFAULT 'USER'" )
	private String role;
		
//	@OneToMany(mappedBy = "employee", cascade = CascadeType.ALL)
//	private List<Issue> issues;

}
