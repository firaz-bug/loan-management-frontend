package org.team1.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.team1.entities.Issue;

public interface IssueRepository extends JpaRepository<Issue, Integer>{
//	List<Issue> findByEmployeeEmployeeId(int employee_id);
}
