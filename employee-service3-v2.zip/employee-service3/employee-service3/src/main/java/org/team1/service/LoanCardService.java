package org.team1.service;

import java.util.List;

import org.team1.entities.LoanCard;


public interface LoanCardService {
	
	LoanCard addNewLoanCard(LoanCard loanCard);
	List<LoanCard> getAll();
	void deleteLoanCard(int id);
	String updateLoanCard(int id,LoanCard loanCard);
	LoanCard findLoanCardById(int id);

}
