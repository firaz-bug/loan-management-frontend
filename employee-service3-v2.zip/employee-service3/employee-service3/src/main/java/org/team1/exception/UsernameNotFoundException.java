package org.team1.exception;

public class UsernameNotFoundException extends RuntimeException {
	public UsernameNotFoundException() {
		super();
	}
	
	public UsernameNotFoundException(String msg) {
		super(msg);
	}
	
}