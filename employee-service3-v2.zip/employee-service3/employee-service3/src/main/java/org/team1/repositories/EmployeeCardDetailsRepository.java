package org.team1.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.team1.entities.EmployeeCardDetails;



public interface EmployeeCardDetailsRepository extends JpaRepository<EmployeeCardDetails, Integer>{
//	Employee_card_details findByEmp_Id(int empId);

}
