package org.team1.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.team1.entities.LoanCard;
import org.team1.service.LoanCardService;

import jakarta.validation.Valid;

@RestController
@CrossOrigin
@RequestMapping("api/loancard")
public class LoanCardController {
	
	@Autowired
	private LoanCardService loanCardService;
	
	@PostMapping
	public ResponseEntity<LoanCard> addNewLoanCard (@Valid @RequestBody LoanCard loanCard){
		LoanCard lc=loanCardService.addNewLoanCard(loanCard);
		return new ResponseEntity<LoanCard>(lc,HttpStatus.CREATED);
		
	}
	
	@GetMapping
	public List<LoanCard> gettAllLoanCards(){
		
		return loanCardService.getAll();
	}
	
	@DeleteMapping("/{loan_id}")
	public void deleteLoanCard(@PathVariable int loan_id){
		 loanCardService.deleteLoanCard(loan_id);
	}
	
	@PutMapping("/{loan_id}")
	public String updateLoanCard(@PathVariable int loan_id,@RequestBody LoanCard loanCard) {
		
		return loanCardService.updateLoanCard(loan_id, loanCard);
	}
	
	@GetMapping("/{loan_id}")
	public LoanCard findLoanCardById(@PathVariable int loan_id) {
		
		return loanCardService.findLoanCardById(loan_id);
	}


}
