package org.team1.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.team1.entities.LoanCard;

public interface LoanCardRepository extends JpaRepository <LoanCard, Integer> {

}
