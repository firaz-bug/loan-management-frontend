package org.team1.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.team1.entities.Employee;
import org.team1.entities.Issue;
import org.team1.entities.Item;
import org.team1.service.IssueService;

import jakarta.validation.Valid;

@RestController
@CrossOrigin
@RequestMapping("/api/issues")
public class IssueController {
	@Autowired
	private IssueService issueService;
	
	@PostMapping
	public ResponseEntity<Issue> addIssue(@Valid  @RequestBody Issue issue){
		
		Issue iss= issueService.addIssue(issue);
			
		return new ResponseEntity<Issue>(iss,HttpStatus.CREATED);
		
	}
	
	@GetMapping
	public List<Issue> getAllIssues(){
		return issueService.getAll();
	}
	
	@GetMapping("/{id}")
	public Issue findIssueById(@PathVariable int id,@RequestBody Item item) {
		
		return issueService.findIssueById(id);
	} 
	
//	@GetMapping("/employee/{employee_id}")
//    public ResponseEntity<List<Issue>> getIssuesByEmployeeId(@PathVariable("employee_id") int employee_id) {
//        List<Issue> issues = issueService.findIssuesByEmployeeId(employee_id);
//        return new ResponseEntity<>(issues, HttpStatus.OK);
//    }
	

}
