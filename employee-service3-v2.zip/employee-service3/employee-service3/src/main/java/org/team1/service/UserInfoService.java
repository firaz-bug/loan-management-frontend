package org.team1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.team1.entities.UserInfo;
import org.team1.repositories.UserInfoRepository;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Service
public class UserInfoService implements UserDetailsService {

	@Autowired
	private UserInfoRepository repository;

	@Autowired
	private PasswordEncoder encoder;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		Optional<UserInfo> userDetail = repository.findByName(username);
		
		// Converting userDetail to UserDetails
		 
		return userDetail.map(userInfo -> {
			UserInfoDetails userDetails = new UserInfoDetails(userInfo);
		

        // You can set the roles in UserInfoDetails here


        return userDetails;})
				.orElseThrow(() -> new UsernameNotFoundException("User not found " + username));
	}
	
	private Collection<? extends GrantedAuthority> getUserAuthorities(String roles) {
	    // Parse roles and create a collection of authorities
	    String[] rolesArray = roles.split(",");
	    List<SimpleGrantedAuthority> authorities = new ArrayList<>();
	    for (String role : rolesArray) {
	        authorities.add(new SimpleGrantedAuthority(role.trim()));
	    }
	    return authorities;
	}
	
	public String addUser(UserInfo userInfo) {
		userInfo.setPassword(encoder.encode(userInfo.getPassword()));
		repository.save(userInfo);
		return "User Added Successfully";
	}

}
