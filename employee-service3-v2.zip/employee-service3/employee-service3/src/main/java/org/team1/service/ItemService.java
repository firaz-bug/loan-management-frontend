package org.team1.service;

import java.util.List;

import org.team1.entities.Employee;
import org.team1.entities.Item;

public interface ItemService {
	Item addItem(Item item);
	List<Item> getAll_I();
	void deleteItem(int id);
	String updateItem(int id, Item item);
	Item findItemById(int item_id);
}
