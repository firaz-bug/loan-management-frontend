package org.team1.entities;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class AuthResponse {
	private String accessToken;
	private String tokenType="Bearer";
	private Collection<? extends GrantedAuthority> authorities;
	
	public AuthResponse(String accessToken, Collection<? extends GrantedAuthority> authorities) {
        this.accessToken = accessToken;
        this.authorities = authorities;
    }
}
