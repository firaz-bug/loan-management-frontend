package org.team1.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.team1.entities.LoanCard;
import org.team1.exception.EmployeeAppException;
import org.team1.exception.LoanCardNotFoundException;
import org.team1.repositories.LoanCardRepository;

import jakarta.transaction.Transactional;

//import org.team1.service.LoanCardService;

@Service
public class LoanCardServiceImpl implements LoanCardService{
	
	@Autowired
	private LoanCardRepository loanCardRepository;

	@Override
	@Transactional
	public LoanCard addNewLoanCard(LoanCard loanCard) {
		// TODO Auto-generated method stub
		return loanCardRepository.save(loanCard);
	}

	@Override
	public List<LoanCard> getAll() {
		// TODO Auto-generated method stub
		return loanCardRepository.findAll();
	}

	@Override
	public void deleteLoanCard(int id) {
		// TODO Auto-generated method stub
		Optional<LoanCard> optionalLoanCard = loanCardRepository.findById(id);
		if(!optionalLoanCard.isPresent()) {
			throw new LoanCardNotFoundException("LoanCard with id "+ id +" not found.");
		}
		
		loanCardRepository.deleteById(id);
		
	}

	@Override
	public String updateLoanCard(int id, LoanCard loanCard) {
		// TODO Auto-generated method stub
		loanCard.setLoan_id(id);
		loanCardRepository.save(loanCard);
		return "Loan Card with id "+id+" updated successfully";
	}

	@Override
	public LoanCard findLoanCardById(int id) {
		// TODO Auto-generated method stub
		LoanCard loanCard=loanCardRepository.findById(id)
				.orElseThrow(()->new EmployeeAppException(HttpStatus.NOT_FOUND, "Loan Card with Id "+id +" not found"));
		return loanCard;
	}

}
