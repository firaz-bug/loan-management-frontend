package org.team1.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.team1.entities.Employee;
import org.team1.entities.EmployeeCardDetails;
import org.team1.exception.EmployeeAppException;
import org.team1.exception.EmployeeCardDetailsNotFoundException;
import org.team1.exception.EmployeeNotFoundException;
import org.team1.repositories.EmployeeCardDetailsRepository;

import jakarta.transaction.Transactional;

@Service
public class EmployeeCardDetailsServiceImpl implements EmployeeCardDetailsService{

	@Autowired
	private EmployeeCardDetailsRepository employeeCardDetailsRepository;
	
	@Override
	@Transactional
	public EmployeeCardDetails addCardDetails(EmployeeCardDetails employeeCardDetails) {
		// TODO Auto-generated method stub
		return employeeCardDetailsRepository.save(employeeCardDetails);
//		return new ResponseEntity<Employee_card_details>(employee_card_details, HttpStatus.CREATED);
	}
	
	@Override
	public List<EmployeeCardDetails> getAll() {
		// TODO Auto-generated method stub
		return employeeCardDetailsRepository.findAll();
	}

	@Override
	public void deleteEmployeeCardDetails(int id) {
		// TODO Auto-generated method stub
		Optional<EmployeeCardDetails> optionalEmployeeCardDetails = employeeCardDetailsRepository.findById(id);
		if(!optionalEmployeeCardDetails.isPresent()) {
			throw new EmployeeCardDetailsNotFoundException("Employee Card Details with id "+ id +" not found.");
		}
		
		employeeCardDetailsRepository.deleteById(id);
		
	}

	@Override
	public EmployeeCardDetails findEmployeeCardDetailsById(int id) {
		// TODO Auto-generated method stub
		EmployeeCardDetails ecd=employeeCardDetailsRepository.findById(id)
				.orElseThrow(()->new EmployeeAppException(HttpStatus.NOT_FOUND, "Employee Card Details with Id "+id +" not found"));
		return ecd;
	}


	

}
