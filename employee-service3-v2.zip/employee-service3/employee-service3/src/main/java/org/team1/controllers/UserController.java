package org.team1.controllers;

import java.util.Collection;
import java.util.Collections;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;
import org.team1.entities.AuthRequest;
import org.team1.entities.AuthResponse;
import org.team1.entities.UserInfo;
import org.team1.repositories.UserInfoRepository;
import org.team1.service.JwtService;
import org.team1.service.UserInfoDetails;
import org.team1.service.UserInfoService;

@RestController
@RequestMapping("/auth")
public class UserController {

	@Autowired
	private UserInfoService service;
	
	@Autowired
	private UserInfoRepository repo;

	@Autowired
	private JwtService jwtService;

	@Autowired
	private AuthenticationManager authenticationManager;

	@GetMapping("/welcome")
	public String welcome() {
		return "Welcome this endpoint is not secure";
	}

	@PostMapping("/addNewUser")
	public String addNewUser(@RequestBody UserInfo userInfo) {
		return service.addUser(userInfo);
	}

	@GetMapping("/user/userProfile")
	@PreAuthorize("hasAuthority('ROLE_USER')")
	public String userProfile() {
		return "Welcome to User Profile";
	}

	@GetMapping("/admin/adminProfile")
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	public String adminProfile() {
		return "Welcome to Admin Profile";
	}

	@PostMapping("/generateToken")
	public ResponseEntity<AuthResponse> authenticateAndGetToken(@RequestBody AuthRequest authRequest) {
		Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()));
		AuthResponse response = new AuthResponse();
		
		 Optional<UserInfo> userInfo = repo.findByName(authRequest.getUsername());
		 
		
		if (authentication.isAuthenticated()) {
			String token =  jwtService.generateToken(authRequest.getUsername());
			// Extract the authorities from the UserInfoDetails object if present, otherwise an empty list
			Collection<? extends GrantedAuthority> authorities = userInfo
			        .map(user -> {
			            UserInfoDetails userDetails = new UserInfoDetails(user);
			            return userDetails.getAuthorities();
			        })
			        .orElse(Collections.emptyList());



			
			response.setAccessToken(token);
			response.setAuthorities(authorities);
		} else {
			throw new UsernameNotFoundException("invalid user request !");
		}
		return ResponseEntity.ok(response);
	}

}

