package org.team1.service;

import java.util.List;

import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.team1.entities.Employee;
import org.team1.entities.EmployeeDetails;

public interface EmployeeService {

	Employee addEmployee(Employee employee);
	List<Employee> getAll();
	void deleteEmployee(int id);
	String updateEmployee(int id,Employee employee);
	Employee findEmployeeById(int id);
	EmployeeDetails loadUserByUsername(String username) throws UsernameNotFoundException;
}
