package org.team1.exception;

public class LoanNotFoundException extends RuntimeException {
	public LoanNotFoundException() {
		super();
	}
	
	public LoanNotFoundException(String msg) {
		super(msg);
	}
}
